# Sparks-Foundation-Internship-Tasks
This repo contains all taks submitted under the internship of The Sparks Foundation(All )

1. Basic Banking App.
2. Payment Gateway Integration.
3. Social Media Integration
