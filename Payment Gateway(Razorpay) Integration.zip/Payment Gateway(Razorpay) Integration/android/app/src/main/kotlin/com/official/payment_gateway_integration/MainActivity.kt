package com.official.payment_gateway_integration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
